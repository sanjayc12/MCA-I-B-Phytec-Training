#include<stdio.h>
int main()
{
        int a[2][3]={{10,20,30},{40,50,60}};
        // int array[5]={{1,2},{3,4,5}};
        int *q;
        q=&a[0][0];
       
        int **ptr;
        ptr=&q;
        printf("%d\n",a);
        printf("%d\n",*(a+1));
        printf("%d\n",*(a+0));
        printf("%d\n",*(*(a+1)+0));
        printf("%d\n",*(*(a+1)+1));
        printf("%d\n",*(*(a+1)+2));
        printf("%d\n",*(*(a+0)+0));
        printf("%d\n",*(*(a+0)+1));
        printf("%d\n",*(*(a+0)+2));
        return 0;
}
