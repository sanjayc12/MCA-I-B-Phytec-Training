#include<stdio.h>
int  greater(){
int a,b,c;
        printf("Enter the three numbers\n");
        scanf("%d%d%d",&a,&b,&c);
        if(a>b){
                if(a>c){
                printf("a is greater than");
                }else{
                        printf("c is greater than");
        }}
        else{
                if(b>c){
                        printf("b is greater than");
                }
                else{
                        printf("c is greater than");
                }
        }
        return 0;
}

