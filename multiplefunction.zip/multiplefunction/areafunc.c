#include<stdio.h>
#include"function.h"


int main(){
        int a=10,b=10;
        square(a);
        rectangle(a,b);
        circle(a);
        return 0;
}

