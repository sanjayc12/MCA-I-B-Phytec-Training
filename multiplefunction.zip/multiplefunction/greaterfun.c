#include<stdio.h>
#include"function.h"

int main(){
	greater();
	return 0;
}
