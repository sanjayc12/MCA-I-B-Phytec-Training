int square(int);
int rectangle(int,int);
int circle(int);


void greater(void);
