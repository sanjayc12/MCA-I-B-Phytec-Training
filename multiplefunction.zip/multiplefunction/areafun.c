#include<stdio.h>
int square(int s){
        int area;
        area=s*s;
        printf("%d\n",area);
        return area;
}
int rectangle(int l,int b){
        int area;
        area=l*b;
        printf("%d\n",area);
        return area;
}
int circle(int r){
        int pi=3.14,area;
        area=r*r*pi;
        printf("%d\n",area);
        return area;
}

