#include<stdio.h>
int main(){
	char a[5]="hell";
	printf("%s",a);
}
