#include<stdio.h>
int main(){
char a[4]="sam";
char b[4]="sam";
char c[20];

for(int i=0;i<4;i++){
	c[i]=a[i]+b[i];
		
}



printf("%c",c[i]);
}
