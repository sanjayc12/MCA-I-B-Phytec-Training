#include<stdio.h>
int main(){
    char a[7] = "sanjay";  
    char b[20];           
    int n = sizeof(a) / sizeof(a[0]);  

    
    for(int i = 0; i < n; i++){
        b[i] = a[i];
    }
    b[n] = '\0';  

    printf("%s", b);  

    return 0;
}

